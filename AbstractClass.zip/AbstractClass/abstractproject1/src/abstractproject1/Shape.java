package abstractproject1;

abstract public class Shape 
{

	public abstract Double calculatePerimeter();


}
