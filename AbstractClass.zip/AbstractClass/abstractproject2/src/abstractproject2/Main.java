package abstractproject2;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int choice;
        int noOfStall,noOfShow,noOfSeatsPerShow;
        String name,detail,ownerName;
        int revenue;
        Scanner input=new Scanner(System.in);
        Event e1=new Exhibition();
        Event e2=new StageEvent();
        System.out.println("Enter the name of the event");
        name=input.nextLine();
        System.out.println("Enter the detail of the event");
        detail=input.nextLine();
        System.out.println("Enter the owner name of the event");
        ownerName=input.nextLine();
        System.out.println("Enter the type of event:");
        System.out.println("1.Exhibition\n2.Stage Event");
        choice=input.nextInt();
        switch(choice)
        {
        case 1:
        	System.out.println("Enter the number of stalls");
        	noOfStall=input.nextInt();
        	((Exhibition)e1).setNoOfStall(noOfStall);
        	e1.projectedRevenue();
        	break;
        	
        case 2:
        	System.out.println("Enter the number of shows");
        	noOfShow=input.nextInt();
        	noOfSeatsPerShow=input.nextInt();
        	((StageEvent)e2).setNoOfShow(noOfShow);
        	((StageEvent)e2).setNoOfSeatsPerShow(noOfSeatsPerShow);
        	e2.projectedRevenue();
            break;
	}
	}

}
