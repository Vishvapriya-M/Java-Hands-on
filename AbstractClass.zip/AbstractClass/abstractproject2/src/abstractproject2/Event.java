package abstractproject2;

abstract public class Event {
	
	public abstract Double projectedRevenue();
	String name;
	String detail;
	String ownerName;


	
	}

