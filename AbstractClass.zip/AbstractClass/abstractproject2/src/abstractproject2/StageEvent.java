package abstractproject2;

public class StageEvent extends Event{
	int noOfShow;
	int noOfSeatsPerShow;
	int revenue;
	public int getNoOfShow() {
		return noOfShow;
	}
	public void setNoOfShow(int noOfShow) {
		this.noOfShow = noOfShow;
	}
	public int getNoOfSeatesPerShow() {
		return noOfSeatsPerShow;
	}
	public void setNoOfSeatsPerShow(int noOfSeatsPerShow) {
		this.noOfSeatsPerShow = noOfSeatsPerShow;
	}
	public Double projectedRevenue()
	{
		revenue= 50*noOfShow*noOfSeatsPerShow;
		System.out.println("The projected revenue of that event is"+" "+revenue);
		return 0.0;
		}

}
