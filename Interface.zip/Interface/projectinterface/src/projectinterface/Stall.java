package projectinterface;

public interface Stall {
	public void display();
	

}
