package projectinterface;

public class PremiumStall implements Stall{
	
	String stallName;
	int cost;
	String ownerName;
	int numberOfProjectors;
	public PremiumStall(String stallName, int cost, String ownerName, int numberOfProjectors) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.ownerName = ownerName;
		this.numberOfProjectors = numberOfProjectors;
	}
	public String getStallName() {
		return stallName;
	}
	public void setStallName(String stallName) {
		this.stallName = stallName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getNumberOfProjectors() {
		return numberOfProjectors;
	}
	public void setNumberOfProjectors(int numberOfProjectors) {
		this.numberOfProjectors = numberOfProjectors;
	}
	public void display()
	{
		System.out.println("Stall name");
		System.out.println("stall cost");
		System.out.println("owner name");
		System.out.println("number of projectors");
	
	}

}
