package projectinterface;

public class ExecutiveStall implements Stall{
	String stallName;
	int cost;
	String ownerName;
	int numberOfScreens;
	public String getStallName() {
		return stallName;
	}
	public void setStallName(String stallName) {
		this.stallName = stallName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getNumberOfScreens() {
		return numberOfScreens;
	}
	public void setNumberOfScreens(int numberOfScreens) {
		this.numberOfScreens = numberOfScreens;
	}
	public ExecutiveStall(String stallName, int cost, String ownerName, int numberOfScreens) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.ownerName = ownerName;
		this.numberOfScreens = numberOfScreens;
	}
	public void display()
	{
		System.out.println("Stall name");
		System.out.println("stall cost");
		System.out.println("owner name");
		System.out.println("number of screens");

	}

}
