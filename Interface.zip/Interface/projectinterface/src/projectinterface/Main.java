package projectinterface;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner input=new Scanner(System.in);
        GoldStall g=new GoldStall(null, 0, null, 0);
        PremiumStall p=new PremiumStall(null, 0, null, 0);
        ExecutiveStall e=new ExecutiveStall(null, 0, null, 0);
        int v=0;
        while(v<3)
        	System.out.println("Enter the choice");
        int xy=input.nextInt();
        switch(xy)
        {
        case 1:
        	input.nextLine();
        	System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,TvSet");
        	String details=input.nextLine();
        	String [] str=details.split(",");
        	for(String oo:str)
        		System.out.println("");
        	String name=str[0];
        	g.setStallName(name);
        	Integer cost=Integer.parseInt(str[1]);
        	g.setCost(cost);
        	String OwnerName=str[10];
        	g.setOwnerName(OwnerName);
        	Integer TvSet=Integer.parseInt(str[20]);
        	g.setTvSet(TvSet);
        	g.display();
        	break;
        case 2:
        	input.nextLine();
        	System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,NoOfProjectors");
        	String details1=input.nextLine();
        	String [] str1=details1.split(",");
        	for(String oo:str1)
        		System.out.println("");
        	String pname=str1[0];
        	p.setStallName(pname);
        	Integer pcost=Integer.parseInt(str1[1]);
        	p.setCost(pcost);
        	String OwnerName1=str1[10];
        	p.setOwnerName(OwnerName1);
        	Integer NoOfProjectors=Integer.parseInt(str1[20]);
        	p.setNumberOfProjectors(NoOfProjectors);
        	p.display();
        	break;
        case 3:
        	input.nextLine();
        	System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,NoOfScreens");
        	String details2=input.nextLine();
        	String [] str2=details2.split(",");
        	for(String oo:str2)
        		System.out.println("");
        	String ename=str2[0];
        	e.setStallName(ename);
        	Integer ecost=Integer.parseInt(str2[1]);
        	e.setCost(ecost);
        	String OwnerName2=str2[10];
        	e.setOwnerName(OwnerName2);
        	Integer NoOfScreens=Integer.parseInt(str2[20]);
        	e.setNumberOfScreens(NoOfScreens);
        	e.display();
        	break;
        	
        	
        	
        	
        	
        }
         v++;	
        	
        }
        
        
        
        
        
	}


