package projectseven;

public class Delivery {

	Long over,balls,runs;
	String batsman,bowler,nonstriker;
	Delivery(){
	}
	Delivery(Long over,Long balls, Long runs,String batsman,String bowler,String nonstriker)
	{
		this.over=over;
		this.balls=balls;
		this.runs=runs;
		this.batsman=batsman;
		this.bowler=bowler;
		this.nonstriker=nonstriker;
	}
	public Long getOver() {
		return over;
	}
	public void setOver(Long over) {
		this.over = over;
	}
	public Long getBalls() {
		return balls;
	}
	public void setBalls(Long balls) {
		this.balls = balls;
	}
	public Long getRuns() {
		return runs;
	}
	public void setRuns(Long runs) {
		this.runs = runs;
	}
	public String getBatsman() {
		return batsman;
	}
	public void setBatsman(String batsman) {
		this.batsman = batsman;
	}
	public String getBowler() {
		return bowler;
	}
	public void setBowler(String bowler) {
		this.bowler = bowler;
	}
	public String getNonstriker() {
		return nonstriker;
	}
	public void setNonstriker(String nonstriker) {
		this.nonstriker = nonstriker;
	}
	

	}

