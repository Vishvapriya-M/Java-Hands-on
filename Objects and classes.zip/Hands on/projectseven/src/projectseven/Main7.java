package projectseven;
import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Long over,balls,runs;
        String batsman,bowler,nonstriker;
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the over");
        over=input.nextLong();
        System.out.println("Enter the balls");
        balls=input.nextLong();
        System.out.println("Enter the runs");
        runs=input.nextLong();
        input.nextLine();
        System.out.println("Enter batsman name");
        batsman=input.nextLine();
        System.out.println("Enter bowler name");
        bowler=input.nextLine();
        System.out.println("Enter nonstriker");
        nonstriker=input.nextLine();
        Delivery d=new Delivery(over,balls,runs,batsman,bowler,nonstriker);
        System.out.println("Delivery details");
        System.out.println("Overs:"+d.getOver());
        System.out.println("Balls:"+d.getBalls());
        System.out.println("Runs:"+d.getRuns());
        System.out.println("Batsman:"+d.getBatsman());
        System.out.println("Bowler:"+d.getBowler());
        System.out.println("Nonstriker:"+d.getNonstriker());      
	}

}
