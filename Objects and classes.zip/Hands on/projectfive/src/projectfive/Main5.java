package projectfive;
import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name,city;
		Scanner input=new Scanner(System.in);
	    System.out.println("enter the venue name:");
	    name=input.nextLine();
	    System.out.println("Enter the city name");;
	    city=input.nextLine();
	    Venue v=new Venue(name,city);
	    v.display();
	    int ch;
	    System.out.println("Menu\n1.update venue name\n 2.update city name \n 3. all informations correct /exit \n type 1 or 2 or 3");
	    ch=input.nextInt();
	    input.nextLine();
	    switch(ch)
	    {
	    case 1:
	    	System.out.println("Enter the venue name:");
	    	name=input.nextLine();	
	    	v.setName(name);
	    	v.display();
	    	break;
	    case 2:
	    	System.out.println("enter the city name");
	    	city=input.nextLine();
	    	v.display();
	    	break;
	    case 3:
	    	v.display();
	    	break;
	    	
	    	
	    
	    }
	}

}
