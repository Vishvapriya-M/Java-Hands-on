package projecteight;

import java.util.Scanner;

public class Main8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Long over,ball;
		String wicketType,playerName,bowlerName;
		String details;
		String[] wicket;
		int Wicket;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the no of wickets");
		Wicket=input.nextInt();
		input.nextLine();
		
		for(int i=1;i<=Wicket;i++)
		{
			System.out.println("Enter the details of wicket"+i);
			details=input.nextLine();
			String[] items=details.split(",");
			over=Long.parseLong(items[0]);
			ball=Long.parseLong(items[1]);
			wicketType=items[2];
			playerName=items[3];
			bowlerName=items[4];
			Wicket w=new Wicket(over,ball,wicketType,playerName,bowlerName);
			System.out.println("Wicket details"+i);
		}
		

	}

}
