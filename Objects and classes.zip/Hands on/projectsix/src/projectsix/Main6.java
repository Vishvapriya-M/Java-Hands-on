package projectsix;
import java.util.Scanner;
public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		Long runs;
		String detail;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Extra Type Details");
		detail=input.nextLine();
		String[]items=detail.split("#");
		name=items[0];
		runs=Long.parseLong(items[1]);
		ExtraType e=new ExtraType(name,runs);
		System.out.println("ExtraType Details");
		System.out.println("ExtraType:"+e.getName());
		System.out.println("Runs:"+e.getRuns());

	}

}
