package projectfour;
import java.util.Scanner;
public class Main4 {
	public static void main(String args[])
	{
	String name,country,skill;
	Scanner input=new Scanner(System.in);
	Player player=new Player();
	System.out.println("Enter name");
	player.name=input.nextLine();
	System.out.println("Enter country");
	player.country=input.nextLine();
	System.out.println("Enter Skill");
	player.skill=input.nextLine();
	player.displayDetails(name,country,skill);
	
}
}