package projectfour;

public class Player {
	public void displayDetails(String name,String country,String skill)
	{
	System.out.println("Player details");
	System.out.println("Player name"+name);
	System.out.println("player country"+country);
	System.out.println("player skill"+skill);
	
}
}