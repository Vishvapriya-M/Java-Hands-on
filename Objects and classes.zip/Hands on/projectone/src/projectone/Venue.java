package projectone;

public class Venue {

	String name;
	String city;
	}
