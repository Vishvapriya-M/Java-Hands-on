package projecttwo;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		Player player=new Player();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a name:");
		player.name=input.nextLine();
		System.out.println("Enter the country name:");
		player.country=input.nextLine();
		System.out.println("Enter a skill:");
		player.skill=input.nextLine();
		System.out.println("Player details");
		System.out.println("Player name:"+player.name);
		System.out.println("Player country:"+player.country);
		System.out.println("Print skill:"+player.skill);		
		

	}

}
