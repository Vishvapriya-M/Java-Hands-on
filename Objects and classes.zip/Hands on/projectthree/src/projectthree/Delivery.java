package projectthree;

public class Delivery{
	
	Long over;
	Long ball;
	Long runs;
	String batsman;
	String bowler;
	String nonstriker;

}