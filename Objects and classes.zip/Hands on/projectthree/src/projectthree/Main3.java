package projectthree;
import java.util.Scanner;
public class Main3 {

	public static void main(String[] args) {
		Long over,ball,runs;
		String batsman,bowler,nonstriker;
		Scanner input=new Scanner(System.in);
		Delivery delivery=new Delivery();
		System.out.println("Enter the over");
		delivery.over=input.nextLong();
		System.out.println("Enter the ball");
		delivery.ball=input.nextLong();
		System.out.println("Enter the runs");
		delivery.runs=input.nextLong();
		input.nextLine();
		System.out.println("Enter the batsman name");
		delivery.batsman=input.nextLine();
		System.out.println("Enter the bowler name");
		delivery.bowler=input.nextLine();		
		System.out.println("Enter the nonstriker name");
		delivery.nonstriker=input.nextLine();
		System.out.println("Delivery Details");
		System.out.println("Over:"+delivery.over);
		System.out.println("Ball:"+delivery.ball);
		System.out.println("Runs:"+delivery.runs);
		System.out.println("Batsman:"+delivery.batsman);
		System.out.println("Bowler:"+delivery.bowler);
		System.out.println("Nonstriker:"+delivery.nonstriker);
	}

}
