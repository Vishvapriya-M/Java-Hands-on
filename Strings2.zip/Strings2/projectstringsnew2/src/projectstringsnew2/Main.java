package projectstringsnew2;

import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the email id");
		 String email= sc.nextLine();
		   System.out.println("The E-mail ID is: " + email);
		   String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		   if(email.matches(regex)&& email.endsWith("com")) {
		   
		   System.out.println("valid email address");
		}
		   else {
			   System.out.println("Invalid email address");
		   }

}
}
