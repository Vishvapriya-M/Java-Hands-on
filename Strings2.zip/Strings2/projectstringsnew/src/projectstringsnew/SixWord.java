package projectstringsnew;
import java.util.Scanner;

public class SixWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
            Scanner sc=new Scanner(System.in);
            System.out.println("Address1 :");
            String s1=sc.nextLine();
            System.out.println("Address2 :");
            String s2=sc.nextLine();
            int c1=s1.length();
            int c2=s2.length();
            if(s1.contentEquals(s2)) {
            	System.out.println("Red");
            }
            else if(s1.equalsIgnoreCase(s2)){
            	System.out.println("Blue");
            }
            else if(c1>c2) {
            	System.out.println("Yellow");
            }
          
            else {
            	System.out.println("Green");
            }
            
	}

}

