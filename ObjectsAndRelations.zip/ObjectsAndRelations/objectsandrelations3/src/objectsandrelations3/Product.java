package objectsandrelations3;

public class Product {
	int product_code;
	String product_name;
	double price;
	int stock;
	
	
	public int getProduct_code() {
		return product_code;
	}
	public void setProduct_code(int product_code) {
		this.product_code = product_code;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int product_code, String product_name, double price, int stock) {
		super();
		this.product_code = product_code;
		this.product_name = product_name;
		this.price = price;
		this.stock = stock;
	}
	void checkPrice(Product pr,Product pr2) {
		if(pr.getPrice()>pr2.getPrice()) {
			System.out.println(pr.getProduct_name()+"is cheaper than "+pr2.getProduct_name());
		}
		else {
			System.out.println(pr.getProduct_name()+"is costlier than"+pr2.getProduct_name());
			
		}
		
		
	}
	void display(){
		
		System.out.println("product code"+product_code);
		System.out.println("product_name"+product_name);
		System.out.println("prices: "+price);
		System.out.println("stocks:"+stock);
	}
	
	

}



