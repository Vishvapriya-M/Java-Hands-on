package projectExceptionHandling;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int noOfDays,v,cost;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the cost of the items for n days");
		cost=input.nextInt();
		System.out.println("Enter the value of n");
		try 
		{
		noOfDays=input.nextInt();
		v=cost/noOfDays;
		System.out.println("cost per day of of the items is"+v);

	}
		catch(ArithmeticException ae)
		{
			System.out.println("Enter a valid number");
		}

}
	}