package projectstringtwo;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		String str1;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Humpty sentence");
		str=input.nextLine();
		System.out.println("Enter dumpty sentence");
		str1=input.nextLine();
		if(str.contains(str1)==true)
		{
			System.out.println("Found");
		}
		else
		{
			System.out.println("Not Found");
		}

	}

}
