package projectstringsix;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentences:");
		String humty=input.nextLine();
		System.out.println("Humpty says:"+humty);
		System.out.println("What Dumpty want to insert & where?");
		String insert1=input.nextLine();
		
		System.out.println("Enter position:");
		int position=input.nextInt();
		StringBuffer stringbuffer = new StringBuffer(humty);
		stringbuffer.insert(position,insert1);

		System.out.println("Humpty's New Sentense :"+stringbuffer);
		
	}

}