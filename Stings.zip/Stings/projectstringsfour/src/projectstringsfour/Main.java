package projectstringsfour;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str,str1,str2;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter humpty sentence");
		str=input.nextLine();
		System.out.println("Word to replace");
		str1=input.nextLine();
		System.out.println("Synonym");
		str2=input.nextLine();
		String replaceString=str.replaceAll(str1,str2 );
		System.out.println("Replaced string:"+replaceString);
		}

}
