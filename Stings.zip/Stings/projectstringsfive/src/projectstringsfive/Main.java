package projectstringsfive;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentence :");
		String str=input.nextLine();
		String convertedString=str.toUpperCase();
		System.out.println("Converted String :"+ convertedString);
		
	}

}