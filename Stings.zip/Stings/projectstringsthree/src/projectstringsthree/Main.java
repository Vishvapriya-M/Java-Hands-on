package projectstringsthree;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
	    StringBuilder str1=new StringBuilder();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter humpty sentence");
		str=input.nextLine();
		str1.append(str);
		System.out.println("dumpty says"+str1.reverse());	
        }	

	}

