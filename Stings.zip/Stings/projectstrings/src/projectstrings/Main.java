package projectstrings;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		String str1;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentence:");
		str=input.nextLine();
		System.out.println("Enter Dumpty's Sentence:");
		str1=input.nextLine();
		System.out.println("Concatenated String:");
		System.out.println(str+"."+str1);	

	}

}
