package collections4;
import java.util.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		
		HashSet numbers=new HashSet();
		ArrayList a= new ArrayList();
		BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
		
	    while(true)
	    {
	    	numbers.add(input.readLine());
	    	System.out.println("Do you want to continue");
	    	String name=input.readLine();
	    	
	    	if(input.equals("y"))
	    	{
	    		System.out.println("Enter the username");
	    	}
	    	else 
	    	{
	    		break;
	    	
	    	}
	    	    	
	    }System.out.println("the unique number of username"+numbers.size());
	
}
}

	
