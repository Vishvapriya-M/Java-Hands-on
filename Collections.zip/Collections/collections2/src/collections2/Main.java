package collections2;

import java.util.Scanner;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> hall=new ArrayList<>();
		int noOfHall;
		String search;
		Scanner input=new Scanner(System.in);
		System.out.println("enter the no of halls");
		noOfHall=input.nextInt();
		input.nextLine();
		for(int i=1;i<=noOfHall;i++)
		{
			System.out.println("enter the hall name"+i);
			hall.add(input.nextLine());
		}
		System.out.println("enter the hall name to be searched ");
		search=input.nextLine();
		if(hall.contains(search)==true)
			System.out.println(search+"is fount at position"+hall.indexOf(search));
		else
			System.out.println(search+"hall is not found");
		}
	}


