package collections3;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;


public class Main {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		HashSet s=new HashSet();
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the username");
		String s1=b.readLine();
		s.add(s1);
		while(true)
		{
			System.out.println("do you want to continue(y/n)");
			String str=b.readLine();
			if(str.equals("y"))
			{
				System.out.println(("enter the user name"));
				String s3=b.readLine();
				s.add(s3);
			}
			else
			{
				break;
			}
			int size=s.size();
			System.out.println("there are"+size+"number od unique names");
			}
		}
	}


