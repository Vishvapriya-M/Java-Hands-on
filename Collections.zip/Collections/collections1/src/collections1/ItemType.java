package collections1;


public class ItemType {
	
		String name,name1;
		Double deposit,deposit1;
		Double costPerDay,costPerDay1;
		
		

	}


