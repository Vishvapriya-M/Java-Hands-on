package collections1;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name,name2;
		Double deposit,deposit2;
		Double costPerDay,costPerDay2;
		String option1,option2;
		ArrayList a=new ArrayList();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the details of item type 1");
		System.out.println("Name:");
		name=input.nextLine();
		System.out.println("Deposit");
		deposit=input.nextDouble();
		System.out.println("Cost per day");
		costPerDay=input.nextDouble();
		input.nextLine();
		System.out.println("Do you want to continue?(y/n)");
		option1=input.nextLine();
		a.add(name);
		a.add(deposit);
		a.add(costPerDay);
		if(option1.contains("y"))
		{
			System.out.println("Enter the details of item type 2");
			System.out.println("Name:");
			name2=input.nextLine();
			System.out.println("Deposit");
			deposit2=input.nextDouble();
			System.out.println("Cost per day");
			costPerDay2=input.nextDouble();
			System.out.println("Do you want to continue?(y/n)");
			option2=input.nextLine();
			a.add(name2);
			a.add(deposit2);
			a.add(costPerDay2);
			System.out.println("name"+a);
			System.out.println("Deposit"+a);
			System.out.println("Cost per day"+a);
			
		}
		else
		{
			System.out.println("name"+a);
			System.out.println("deposit"+a);
			System.out.println("Cost per day"+a);
			
			
		}
		

	}

}
