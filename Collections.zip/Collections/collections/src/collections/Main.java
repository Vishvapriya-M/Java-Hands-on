package collections;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.ArrayList;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1;
		String s2;
		String option1,option2;
		ArrayList a=new ArrayList();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the usename1");
		s1=input.nextLine();
		System.out.println("Do you want to continue?(y/n)");
		option1=input.nextLine();
		a.add(s1);
		if(option1.contains("y"))
		{
			System.out.println("enter the username2");
			s2=input.nextLine();
			System.out.println("Do you want to continue?(y/n)");
			option2=input.nextLine();
			a.add(s2);
			System.out.println("the name entered are"+a);
		
			
		}
		else
		{
			System.out.println("the name entered are"+a);
			
		}

	}

}
