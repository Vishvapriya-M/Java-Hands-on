package projectAssignment;

	import java.util.List;
	import java.util.Set;
	import projectAssignment.bankAccount.BankDetails;
	import projectAssignment.bankTransaction.TransactionDetails;

	

	public class Main {

		public static void main(String[] args) {
	      
	        	try {

	    			List<bankAccount> banklist = BankDetails.getInfo();
	    		
	    			
	    			List<bankTransaction> bank1 = TransactionDetails.getTransaction();
	    			List<bankAccount> lists = BankDetails.getBankAccount(banklist, bank1);
	    			System.out.format("\n%-5s %-20s %-20s %-20s %-20s %-20s %-20s", "S.No", "Name", "Bank", "Age", "Gender",
	    					"TranscationDate", "TransactionAmount");

	    			for (bankAccount bank : lists) {

	    				Set<String> keysets = bank.getMapTransaction().keySet();
	    				int sno = 1;
	    				int index = 0;
	    				for (String key : keysets) {
	    					
	    					List<bankTransaction> list = (List<bankTransaction>) bank.getMapTransaction().keySet();
	    					for (bankTransaction bnk : list) {
	    						if (index == 0)
	    							System.out.format("\n%-5s %-20s %-20s %-20s %-20s %-20s %-20s", sno, bank.getName(),
	    									bank.getBank(), bank.getAge(), bank.getGender(), bnk.getTransactionDate(),
	    									bnk.getAmount());
	    						else
	    							System.out.format("\n%-5s %-20s %-20s %-20s %-20s %-20s %-20s", sno, bank.getName(),
	    									bank.getBank(), bank.getAge(), bank.getGender(), bnk.getTransactionDate(),
	    									bnk.getAmount());
	    						index++;
	    						sno++;
	    					}
	    					
	    				}
	        	}
	        	}
	        	
	        	catch(Exception e) {
	        		e.printStackTrace();
	        	}
		}
	
	    		

	}


