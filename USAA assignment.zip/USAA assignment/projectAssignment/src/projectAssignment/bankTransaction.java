package projectAssignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class bankTransaction {
	private String cardNumber,transactionDate;;
	private long amount;
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public bankTransaction(String cardNumber, String transactionDate, long amount) {
		super();
		this.cardNumber = cardNumber;
		this.transactionDate = transactionDate;
		this.amount = amount;
	}
	public bankTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static class TransactionDetails{
		private static List<bankTransaction> banktransaction = new ArrayList<bankTransaction>();

		public static List<bankTransaction> getTransaction() throws Exception {
			try {

				bankTransaction Bank = null;
				String details = "";
				BufferedReader br = new BufferedReader(new FileReader(new File("Resources/Transaction.csv.txt")));

				br.readLine();
				while ((details = br.readLine()) != null) {

					String[] transcationget = details.split(",");
					if (transcationget .length > 0) {
						Bank = new bankTransaction();
						Bank.setCardNumber(transcationget [0]);
						Bank.setTransactionDate(transcationget [1]);
						Bank.setAmount(Long.parseLong(transcationget [2]));
						banktransaction.add(Bank);
					}
					
				}
				for (bankTransaction detail: banktransaction) {

					System.out.printf("CardNumber:%s , Transactiondate:%s  ,Amount:%d\n", detail.getCardNumber(),
							detail.getTransactionDate(), detail.getAmount());

				}
			

			
			} catch (Exception e) {
				System.out.println("hi");
			}

			
			return banktransaction;
		}
	}
	}


