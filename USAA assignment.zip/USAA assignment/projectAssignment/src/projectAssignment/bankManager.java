package projectAssignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class bankManager {
	static BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(System.in));
	public static List<bankAccount> getMappedAccount(List<bankAccount> bankdetail,
			List<bankTransaction> transactions) throws IOException {
		System.out.println("Enter the person data to be searched");
		String person = bufferedreader.readLine();
		
		
	bankAccount account= new bankAccount();
		account.setName(person);
		
		List<bankAccount> bankUsers = new ArrayList<>();

		for (bankAccount bank : bankdetail) {
			if (bank.getName().equals(person)) {
				bankUsers.add(new bankAccount(bank.getName(), bank.getAge(), bank.getGender(), bank.getBank(),
						bank.getCardnumber(), bank.getCardlimit()));

			}
		}
		List<bankAccount> userfinal = new ArrayList<>();

		for (bankAccount accbank : bankUsers) {
			bankAccount banks =getTransaction(accbank,transactions);
			if (banks != null) {
				userfinal.add(banks);
			}
		}

		return userfinal;
	}
	private static bankAccount getTransaction(bankAccount accbank, List<bankTransaction> transactions) {
		List<bankTransaction> translist = new ArrayList<>();
		Object bankTransaction;
		for (bankTransaction banktrans : bankTransaction) {
			if (banktrans.getCardNumber().equals(accbank.getCardnumber())) {
				translist.add(banktrans);
			}
		}

		Map<String, List<bankTransaction>> finaluser = new TreeMap<>();

		finaluser.put(accbank.getBank(),  translist);

		return new bankAccount(accbank.getName(), accbank.getAge(), accbank.getGender(), accbank.getBank(),
				accbank.getCardnumber(),accbank.getCardlimit());


	
		


}

}

